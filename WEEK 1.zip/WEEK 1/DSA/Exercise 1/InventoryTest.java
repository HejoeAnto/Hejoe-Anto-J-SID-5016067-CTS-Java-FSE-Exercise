public class InventoryTest {
    public static void main(String[] args) {

        Inventory inventory = new Inventory();

        Product product1 = new Product("1001", "Soap", 100, 10.50);
        Product product2 = new Product("1002", "Maggi", 200, 20.75);
        Product product3 = new Product("1003", "Snacks", 300, 30.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        System.out.println("Inventory after adding products:");
        System.out.println(inventory);
        System.out.println();

        Product updatedProduct2 = new Product("1002", "Biscuits", 250, 22.50);
        inventory.updateProduct("1002", updatedProduct2);

        System.out.println("Inventory after updating product 1002:");
        System.out.println(inventory);
        System.out.println();

        inventory.deleteProduct("1001");

        System.out.println("Inventory after deleting product 1001:");
        System.out.println(inventory);
        System.out.println();

        Product retrievedProduct = inventory.getProduct("1003");
        System.out.println("Retrieved product 1003:");
        System.out.println(retrievedProduct);
    }
}