import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class ECommerceSearch {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the product id");
    int FindproductbyId=sc.nextInt();

        Product[] products = {
            new Product(3, "Soap", "General"),
            new Product(1, "Laptop", "Electronics"),
            new Product(4, "Headphones", "Accessories"),
            new Product(2, "Biscuts", "Eatables")
        };

       
        
        Product foundProductLinear = linearSearch(products, FindproductbyId);
        if (foundProductLinear != null) {
            System.out.println("Linear Search: Found " + foundProductLinear.getProductName());
        } else {
            System.out.println("Linear Search: Product not found");
        }

        System.out.println();

    
        Product foundProductBinary = binarySearch(products, FindproductbyId);
        if (foundProductBinary != null) {
            System.out.println("Binary Search: Found " + foundProductBinary.getProductName());
        } else {
            System.out.println("Binary Search: Product not found");
        }
    }



    public static Product linearSearch(Product[] products, int productId) {
        Arrays.sort(products, Comparator.comparingInt(Product::getProductId));
        for (Product product : products) {
            if (product.getProductId() == productId) {
                return product; 
            }
        }
        return null; 
    }

    public static Product binarySearch(Product[] products, int productId) {
        int left = 0;
        int right = products.length - 1;
    
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId() == productId) {
                return products[mid]; // Product found
            } else if (products[mid].getProductId() < productId) {
                left = mid + 1; 
            } else {
                right = mid - 1; 
            }
        }
        return null; 
    }
    

    
}
