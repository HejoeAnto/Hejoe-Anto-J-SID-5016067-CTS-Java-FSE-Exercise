public class Main{
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Hejoe", 150.0),
            new Order("2", "Anto", 75.0),
            new Order("3", "Bala", 200.0),
            new Order("4", "Ravi", 120.0)
        };
    
        System.out.println("Orders before sorting:");
        for (Order order : orders) {
            System.out.println(order);
        }
    

        bubbleSort(orders);
        System.out.println("\nOrders sorted by Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    
    
        orders = new Order[]{
            new Order("1", "Hejoe", 150.0),
            new Order("2", "Anto", 75.0),
            new Order("3", "Ravi", 200.0),
            new Order("4", "Varun", 120.0)
        };
    

        quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders sorted by Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }




    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    // Swap orders[j] and orders[j + 1]
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }


    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    public static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
            
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
    
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

}