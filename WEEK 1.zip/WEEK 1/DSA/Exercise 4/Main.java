public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem emp = new EmployeeManagementSystem(5); 

        
        emp.addEmployee(new Employee(1, "Hejoe", "SoftWareDeveloper", 60000));
        emp.addEmployee(new Employee(2, "Anto", "CloudEngineer", 55000));
        emp.addEmployee(new Employee(3, "Bala", "CEO", 75000));
        emp.addEmployee(new Employee(4, "Ravi", "CFO", 65000));
        emp.addEmployee(new Employee(4, "Varun", "CTO", 65000));
        
    
        System.out.println("Employees in the system:");
        emp.traverseEmployees();

        Employee searchResult = emp.searchEmployee(2);
        if (searchResult != null) {
            System.out.println("Found: " + searchResult);
        } else {
            System.out.println("Employee not found.");
        }

        boolean isDeleted = emp.deleteEmployee(3);
        if (isDeleted) {
            System.out.println("Employee with ID 3 deleted successfully.");
        } else {
            System.out.println("Employee not found for deletion.");
        }

        System.out.println("Employees after deletion:");
        emp.traverseEmployees();
    }
}
