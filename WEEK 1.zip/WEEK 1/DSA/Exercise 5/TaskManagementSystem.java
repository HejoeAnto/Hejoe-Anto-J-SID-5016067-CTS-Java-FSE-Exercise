public class TaskManagementSystem {
    //Main
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();


        taskList.addTask(new Task(1, "Complete assignment", "Pending"));
        taskList.addTask(new Task(2, "Prepare presentation", "In Progress"));
        taskList.addTask(new Task(3, "Attend meeting", "Completed"));

        
        System.out.println("All Tasks:");
        taskList.traverseTasks();
        System.out.println();


        Task foundTask = taskList.searchTask(2);
        if (foundTask != null) {
            System.out.println("Found Task: " + foundTask.taskName);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println();

    
        boolean isDeleted = taskList.deleteTask(2);
        if (isDeleted) {
            System.out.println("Task 2 deleted.");
        } else {
            System.out.println("Task not found for deletion.");
        }
        System.out.println();

    
        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
        System.out.println();
    }
}
