import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Why I am Atheist", "Bagdht Singh"),
            new Book(2, "Laedrship Wisdom", "Robin Sharma"),
            new Book(3, "Can't Hurt Me", "David Goggins"),
            new Book(4, "Karuvachi Kaviyam", "Vaira Muthu")
        };

        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        Library library = new Library(books);

        String titleToSearch = "Karuvachi Kaviyam";
        Book foundBookLinear = library.linearSearch(titleToSearch);
        System.out.println("Linear Search: " + (foundBookLinear != null ? foundBookLinear.title : "Book not found"));
        System.out.println();
        
        
        titleToSearch = "Why I am Atheist";
        Book foundBookBinary = library.binarySearch(titleToSearch);
        System.out.println("Binary Search: " + (foundBookBinary != null ? foundBookBinary.title : "Book not found"));
    }
}
