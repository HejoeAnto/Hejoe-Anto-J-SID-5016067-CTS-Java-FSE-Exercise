public class FinancialForecasting {
    // Main 
    public static void main(String[] args) {
        double presentValue = 1000; 
        double growthRate = 0.05; 
        int years = 10; 

        double futureValue = futurePrediction(presentValue, growthRate, years);
        System.out.printf("Future Value after %d years: %.2f%n", years, futureValue);
    }

    public static double futurePrediction(double presentValue, double growthRate, int years) {
        if (years == 0) {
            return presentValue;
        }

        return futurePrediction(presentValue * (1 + growthRate), growthRate, years - 1);
    }

    
    
}
