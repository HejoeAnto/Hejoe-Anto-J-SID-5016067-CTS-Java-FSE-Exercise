
public class Logger {
    
    private Logger()
    {

    }
    static Logger obj=new Logger();

    public static Logger getObject() {
        return obj;
    }
}
    

