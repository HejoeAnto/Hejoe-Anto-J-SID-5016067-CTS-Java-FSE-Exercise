
public class LoggerTestClass {
    //Main
    public static void main(String[] args) {
        Logger obj1=Logger.getObject();
        System.out.println(obj1);

        Logger obj2=Logger.getObject();
        System.out.println(obj2);
         
        //Testing 
        if(obj1==obj2)
        {
            System.out.println("Logger class follows singleton pattern");
        }
    }
}
