public class Main {
    public static void main(String[] args) {

        Student student_obj = new Student("Hejoe", 411, 95.5);

        StudentView view_obj = new StudentView();

        StudentController controller_obj = new StudentController(student_obj, view_obj);

        controller_obj.displayStudentDetails();
        System.out.println();

        controller_obj.setStudentDetails("Anto", 400, 96.5);

        controller_obj.displayStudentDetails();
    }
}