public class StudentController {
    private Student model;
    private StudentView view;

    public StudentController(Student model, StudentView view) {
        this.model = model;
        this.view = view;
    }

    public void setStudentDetails(String name, int id, double grade) {
        model.setStudentName(name);
        model.setStudentId(id);
        model.setStudentGrade(grade);
    }

    public void displayStudentDetails() {
        view.displayStudentDetails(model);
    }
}