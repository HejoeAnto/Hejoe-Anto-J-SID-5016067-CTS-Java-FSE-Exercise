public class StudentView {
    public void displayStudentDetails(Student student) {
        System.out.println("Student Name: " + student.getStudentName());
        System.out.println("Student ID: " + student.getStudentId());
        System.out.println("Student Grade: " + student.getStudentGrade());
    }
}