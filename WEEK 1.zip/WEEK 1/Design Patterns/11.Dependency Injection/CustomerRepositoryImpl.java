public class CustomerRepositoryImpl implements CustomerRepository {
    public Customer findCustomerById(int id) 
    {
        if(id==1)
        {
            return new Customer(id, "Hejoe");
        }
        else{
            return new Customer(id,"Anto");
        }
    }
}
