public class CustomerService {
    public CustomerRepository customerRepo_obj;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepo_obj = customerRepository;
    }

    public Customer getCustomerById(int id) {
        return customerRepo_obj.findCustomerById(id);
    }
}
