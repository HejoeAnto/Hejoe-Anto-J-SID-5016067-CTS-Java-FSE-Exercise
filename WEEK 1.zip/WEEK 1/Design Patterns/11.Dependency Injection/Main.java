
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter customer id:");
        int id=sc.nextInt();
    
        CustomerRepository customerRepo_obj = new CustomerRepositoryImpl();

        //Injection
        CustomerService customerService = new CustomerService(customerRepo_obj);

        Customer obj = customerService.getCustomerById(id);
        System.out.println("Customer ID: " + obj.getId());
        System.out.println("Customer Name: " + obj.getName());
    }
}
