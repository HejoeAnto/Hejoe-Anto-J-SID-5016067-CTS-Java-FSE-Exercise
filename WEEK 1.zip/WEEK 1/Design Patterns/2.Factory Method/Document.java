public interface Document {
    void read();
    void edit();
    void write();
}