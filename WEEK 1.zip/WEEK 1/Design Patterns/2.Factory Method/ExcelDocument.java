public class ExcelDocument implements Document {
    
    public void read() {
       System.out.println("reading in Excel Document");
    }
    
    public void write() {
        System.out.println("writing in Excel Document");
    }
    public void edit() {
        System.out.println("Editing in Excel Document");
    }
    
}