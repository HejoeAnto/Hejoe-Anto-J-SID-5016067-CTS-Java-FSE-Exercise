public class ExcelDocumentFactory extends ExcelDocument {
    public static Document createDocument() {
        return new ExcelDocument();
    }
}