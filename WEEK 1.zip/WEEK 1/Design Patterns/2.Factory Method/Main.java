public class Main {
    public static void main(String[] args) {
        
        Document obj1 = WordDocumentFactory.createDocument();
        obj1.read();
        obj1.edit();
        obj1.write();

        System.out.println();

        Document obj2 = PdfDocumentFactory.createDocument();
        obj2.read();
        obj2.edit();
        obj2.write();

        System.out.println();

        Document obj3 = ExcelDocumentFactory.createDocument();
        obj3.read();
        obj3.edit();
        obj3.write();
    }
}