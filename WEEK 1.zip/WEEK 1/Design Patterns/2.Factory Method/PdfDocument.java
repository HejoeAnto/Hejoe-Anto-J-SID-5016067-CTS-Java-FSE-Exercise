public class PdfDocument implements Document {
    public void read() {
       System.out.println("Reading in Pdf Document");
    }
    
    public void write() {
        System.out.println("writing in pdf Document");
    }
    
    public void edit() {
        System.out.println("Editing in pdf Document");
    }
    
}