public class PdfDocumentFactory extends PdfDocument {
    public static Document createDocument() {
        return new PdfDocument();
    }
}