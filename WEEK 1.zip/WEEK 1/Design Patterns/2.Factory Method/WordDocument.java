public class WordDocument implements Document {
    public void read() {
       System.out.println("reading in Word Document");
    }
    
    public void write() {
        System.out.println("writing in Word Document");
    }
    
    public void edit() {
        System.out.println("editing in Word Document");
    }

    
}