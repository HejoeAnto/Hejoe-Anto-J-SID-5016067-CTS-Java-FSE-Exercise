public class WordDocumentFactory extends WordDocument {
    public static Document createDocument() {
        return new WordDocument();
    }
}