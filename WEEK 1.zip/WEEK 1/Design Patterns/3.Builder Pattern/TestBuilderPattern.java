public class TestBuilderPattern {
    //Main
    public static void main(String[] args) {
        Computer LowEndPC = new Computer.Builder()
                .setCpu(4)
                .setRam(8)
                .setStorage(256)
                .build();


        Computer HighEndPC = new Computer.Builder(8, 32, 1024).build();
        
        System.out.println(HighEndPC);
        System.out.println();
        System.out.println(LowEndPC);
    }
}
