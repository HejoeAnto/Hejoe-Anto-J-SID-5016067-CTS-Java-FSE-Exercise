

public class AdapterPatternTest {
    //Main
    public static void main(String[] args) {
        
        PayPal payPal = new PayPal();
        IppoPay ippoPay = new IppoPay();

        
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);
        PaymentProcessor ippoPayAdapter = new IppoPayAdapter(ippoPay);

    
        payPalAdapter.processPayment(100.0);
        ippoPayAdapter.processPayment(200.0);

        payPalAdapter.validation("hejoeantoj@oksbi");
        ippoPayAdapter.validation("6532 4521 7896 2365");
    }
}
