

public class IppoPay {
    public void cardPayment(double amount) {
        System.out.println("Processing payment of $" + amount + " through IppoPay.");
    }
    public void validateCard(String cardNumber){
        System.out.println("Card validated");
    }
}
