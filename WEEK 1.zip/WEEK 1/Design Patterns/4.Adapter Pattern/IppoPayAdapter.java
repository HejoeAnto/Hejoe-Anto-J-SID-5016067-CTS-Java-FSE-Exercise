

public class IppoPayAdapter implements PaymentProcessor {
    private IppoPay ippoPay;

    public IppoPayAdapter(IppoPay ippoPay) {
        this.ippoPay = ippoPay;
    }

    @Override
    public void processPayment(double amount) {
        ippoPay.cardPayment(amount);
    }
    @Override
    public void validation(String Number) {
        ippoPay.validateCard(Number);
    }
}
