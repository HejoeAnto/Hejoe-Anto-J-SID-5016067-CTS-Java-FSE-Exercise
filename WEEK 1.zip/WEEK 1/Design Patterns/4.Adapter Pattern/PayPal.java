

public class PayPal {
    public void upiPayment(double amount) {
        System.out.println("Processing payment of $" + amount + " through PayPal.");
    }
    public void validateVpaId(String vpaId){
        System.out.println("VPA ID validated");
    }
}
