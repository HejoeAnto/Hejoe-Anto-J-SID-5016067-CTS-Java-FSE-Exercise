

public class PayPalAdapter implements PaymentProcessor {
    private PayPal payPal;

    public PayPalAdapter(PayPal payPal) {
        this.payPal = payPal;
    }

    @Override
    public void processPayment(double amount) {
        payPal.upiPayment(amount);
    }
    @Override
    public void validation(String vpaId){
    payPal.validateVpaId(vpaId);
    }
}