

public interface PaymentProcessor {
    void processPayment(double amount);
    void validation(String Number);
    
}

