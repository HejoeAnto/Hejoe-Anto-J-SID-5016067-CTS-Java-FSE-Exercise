public class Main {
    //Main
    public static void main(String[] args) {


        Notifier obj1 = new EmailNotifier();
        // Email
        obj1.send("Hello via Email!");

        System.out.println();
        
        // SMSNotifierDecorator
        Notifier obj2 = new SMSNotifierDecorator(obj1);
        
        //Email and SMS
        obj2.send("Hello via  Email and SMS!");

        System.out.println();
        
        // SlackNotifierDecorator
         Notifier obj3 = new SlackNotifierDecorator(obj1);
        
        //  Email and Slack
        obj3.send("Hello via  Email and Slack!");
    }
}
