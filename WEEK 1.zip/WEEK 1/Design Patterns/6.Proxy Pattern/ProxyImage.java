public class ProxyImage implements Image {
    private String imageName;
    private RealImage realImage;

    private static RealImage cachedImage;
    private static String cachedImagename;

    public ProxyImage(String imageName) {
        this.imageName = imageName;
    }

    public void display() {
        if (realImage == null) {
            if (imageName.equals(cachedImagename)) {
                realImage = cachedImage;
            } else {
                realImage = new RealImage(imageName);
                cachedImage = realImage;
                cachedImagename = imageName;
            }
        }
        realImage.display();
    }
}
