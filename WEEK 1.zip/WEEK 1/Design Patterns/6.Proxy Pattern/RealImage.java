public class RealImage implements Image {
    private String imageName;

    public RealImage(String imageName) {
        this.imageName = imageName;
        loadImageFromServer();
    }

    private void loadImageFromServer() {
        System.out.println("Loading " + imageName);
    }

    public void display() {
        System.out.println("Displaying " + imageName);
    }
}
