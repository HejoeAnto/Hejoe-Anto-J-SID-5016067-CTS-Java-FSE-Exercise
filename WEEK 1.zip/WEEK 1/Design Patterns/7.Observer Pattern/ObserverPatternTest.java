public class ObserverPatternTest {
    //Main
    public static void main(String[] args) {
        StockMarket obj = new StockMarket();

        Observer mobileApp_obj = new MobileApp("MobileApp");
        Observer webApp_obj = new WebApp("WebApp");

        obj.registerObserver(mobileApp_obj);
        obj.registerObserver(webApp_obj);

        obj.setStockPrice(100.00);
        System.out.println();
        obj.setStockPrice(105.50);
        System.out.println();

        obj.deregisterObserver(mobileApp_obj);

        obj.setStockPrice(110.75);
        System.out.println();
    }
}
