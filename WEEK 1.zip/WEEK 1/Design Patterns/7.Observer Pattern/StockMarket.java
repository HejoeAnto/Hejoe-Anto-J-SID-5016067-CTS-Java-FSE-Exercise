import java.util.ArrayList;
import java.util.List;

public class StockMarket implements Stock {
    private List<Observer> observers;
    private double stockPrice;

    public StockMarket() {
        observers = new ArrayList<>();
    }

    public void setStockPrice(double stockPrice) {
        this.stockPrice = stockPrice;
        notifyObservers();
    }

    public void registerObserver(Observer Obj) {
        observers.add(Obj);
    }

    public void deregisterObserver(Observer Obj) {
        observers.remove(Obj);
    }

    public void notifyObservers() {
        for (Observer Obj : observers) {
            Obj.update(stockPrice);
        }
    }
}
