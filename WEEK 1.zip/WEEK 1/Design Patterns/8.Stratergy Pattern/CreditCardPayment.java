// Implement concrete strategy for credit card payment
public class CreditCardPayment implements PaymentStrategy {
    private String name;
    private String cardNumber;
    private String cvv;
    private String expirationDate;
   
    public CreditCardPayment(String name, String cardNumber,String cvv,String expirationDate) {
        this.name=name;
        this.cardNumber = cardNumber;
        this.cvv=cvv;
        this.expirationDate = expirationDate;
    }

    public void pay(double amount) {
        System.out.println("Paid " + amount + " using credit card named " + name);
    }

    public static CreditCardPayment createObject(String name, String cardNumber,String cvv,String expirationDate)
    {
        return new CreditCardPayment(name, cardNumber, cvv, expirationDate);
    }
}