
public class PayPalPayment implements PaymentStrategy {
    private String AccountName="Hejoe_Anto";
    private String paypalVpaid;

    public PayPalPayment(String paypalVpaid) {
        this.paypalVpaid = paypalVpaid;
    }

    public void pay(double amount) {
        System.out.println("Paid  " + amount + " using PayPal account named " + AccountName);
    }
    public static PayPalPayment createObject(String paypalVpaid)
    {
        return new PayPalPayment(paypalVpaid);
    }
}