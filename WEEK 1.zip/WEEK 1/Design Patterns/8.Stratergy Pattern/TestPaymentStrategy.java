public class TestPaymentStrategy {
    //Main
    public static void main(String[] args) {
        PaymentStrategy ccobj = CreditCardPayment.createObject("Hejoe","1234-5678-9012-3456", "12/2025","cvv");
        PaymentStrategy ppobj =PayPalPayment.createObject("example@gmail.com");

        PaymentContext creditCardContext = new PaymentContext(ccobj);
        PaymentContext paypalContext = new PaymentContext(ppobj);

        

        creditCardContext.PaymentMethod(10000);
        System.out.println();
        paypalContext.PaymentMethod(5000);
    }
}