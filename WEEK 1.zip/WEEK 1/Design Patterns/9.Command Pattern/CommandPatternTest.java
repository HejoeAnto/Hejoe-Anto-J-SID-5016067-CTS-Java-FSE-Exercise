public class CommandPatternTest {
    //Main
    public static void main(String[] args) {
        Light lobj = new Light();
        RemoteControl robj = new RemoteControl();

        
        robj.executeCommand(new LightOnCommand(lobj));
        System.out.println();
        robj.executeCommand(new LightOffCommand(lobj));
    }
}