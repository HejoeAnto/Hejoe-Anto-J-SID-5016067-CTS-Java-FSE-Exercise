public interface Device {
    void on();
    void off();
    void up();
    void down();
}
public interface Command {
    void execute();
}
c

public class OffCommand implements Command {
    private final Device device;

    public OffCommand(final Device device) {
        this.device = device;
    }

    @Override
    public void execute() {
        this.device.off();
    }
}
public class Invoker {
    private final Command onCommand;
    private final Command offCommand;
    private final Command upCommand;
    private final Command downCommand;

    public Invoker(final Command onCommand,
                   final Command offCommand, 
                   final Command upCommand, 
                   final Command downCommand) {
        this.onCommand = onCommand;
        this.offCommand = offCommand;
        this.upCommand = upCommand;
        this.downCommand = downCommand;
    }

    public void clickOn() {
        this.onCommand.execute();
    }

    public void clickOff() {
        this.offCommand.execute();
    }

    public void clickUp() {
        this.upCommand.execute();
    }

    public void clickDown() {
        this.downCommand.execute();
    }
}
public class RemoteApplication {
    public static void main(String[] args) {
        final Light light = new Light();

        final Invoker invoker = new Invoker(
                new OnCommand(light),
                new OffCommand(light),
                new UpCommand(light),
                new DownCommand(light)
        );

        invoker.clickOn();
        invoker.clickOff();
        invoker.clickUp();
        invoker.clickDown();
    }
}
