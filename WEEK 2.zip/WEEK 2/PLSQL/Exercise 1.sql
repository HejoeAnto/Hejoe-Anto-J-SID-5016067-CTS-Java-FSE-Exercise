-- Exercise 2: Error Handling

CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    FromAccountID NUMBER,
    ToAccountID NUMBER,
    Amount NUMBER) AS
    CurrentBalance NUMBER;
BEGIN
    -- Check if the from account has sufficient balance
    SELECT Balance INTO CurrentBalance FROM Accounts WHERE AccountID = FromAccountID;

    IF CurrentBalance < Amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in account ID ' || FromAccountID);
    ELSE
        -- Deduct amount from the source account
        UPDATE Accounts SET Balance = Balance - Amount WHERE AccountID = FromAccountID;

        -- Add amount to the destination account
        UPDATE Accounts SET Balance = Balance + Amount WHERE AccountID = ToAccountID;

        DBMS_OUTPUT.PUT_LINE('Transfer successful: $' || Amount || ' transferred from account ID ' || FromAccountID || ' to account ID ' || ToAccountID);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        -- Log error message
        DBMS_OUTPUT.PUT_LINE('Error during fund transfer: ' || SQLERRM);
        ROLLBACK;  -- Rollback any changes made in case of an error
END SafeTransferFunds;







-- Scenario 2: UpdateSalary

CREATE OR REPLACE PROCEDURE UpdateSalary (
    EmployeeID NUMBER,
    PercentageIncrease NUMBER) AS
    CurrentSalary NUMBER;
BEGIN
    -- Fetch current salary
    SELECT Salary INTO CurrentSalary FROM Employees WHERE EmployeeID = EmployeeID;

    -- Update the salary
    UPDATE Employees 
    SET Salary = CurrentSalary * (1 + PercentageIncrease / 100)
    WHERE EmployeeID = EmployeeID;

    DBMS_OUTPUT.PUT_LINE('Salary updated for employee ID ' || EmployeeID || ': New Salary = ' || (CurrentSalary * (1 + PercentageIncrease / 100)));

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Log error message for non-existing employee
        DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || EmployeeID || ' does not exist.');
    WHEN OTHERS THEN
        -- Log unexpected errors
        DBMS_OUTPUT.PUT_LINE('Error updating salary: ' || SQLERRM);
END UpdateSalary;












-- Scenario 3: AddNewCustomer

CREATE OR REPLACE PROCEDURE AddNewCustomer (
    CustomerID NUMBER,
    Name VARCHAR2(100),
    DOB DATE,
    Balance NUMBER) AS
BEGIN
    -- Insert new customer
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (CustomerID, Name, DOB, Balance, SYSDATE);
    
    DBMS_OUTPUT.PUT_LINE('New customer added: ' || Name);

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        -- Log error for duplicate CustomerID
        DBMS_OUTPUT.PUT_LINE('Error: Customer ID ' || CustomerID || ' already exists.');
    WHEN OTHERS THEN
        -- Log unexpected errors
        DBMS_OUTPUT.PUT_LINE('Error adding new customer: ' || SQLERRM);
END AddNewCustomer;



