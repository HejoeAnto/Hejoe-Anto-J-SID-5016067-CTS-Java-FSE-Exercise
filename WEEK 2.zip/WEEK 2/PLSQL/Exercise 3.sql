-- Exercise 4: Functions

-- Scenario 1: CalculateAge

CREATE OR REPLACE FUNCTION CalculateAge (
    DOB DATE) RETURN NUMBER AS
    Age NUMBER;
BEGIN
    Age := TRUNC(MONTHS_BETWEEN(SYSDATE, DOB) / 12); -- Calculate age in years
    RETURN Age;
END CalculateAge;


-- Scenario 2: CalculateMonthlyInstallment

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    LoanAmount NUMBER,
    InterestRate NUMBER,
    LoanDurationYears NUMBER) RETURN NUMBER AS
    MonthlyRate NUMBER;
    TotalPayments NUMBER;
    MonthlyInstallment NUMBER;
BEGIN
    MonthlyRate := InterestRate / 100 / 12; -- Convert annual interest rate to monthly
    TotalPayments := LoanDurationYears * 12; -- Total number of monthly payments
    
    -- Calculate monthly installment using the formula for an annuity
    MonthlyInstallment := (LoanAmount * MonthlyRate) / (1 - POWER(1 + MonthlyRate, -TotalPayments));

    RETURN MonthlyInstallment;
END CalculateMonthlyInstallment;







-- Scenario 3: HasSufficientBalance

CREATE OR REPLACE FUNCTION HasSufficientBalance (
    AccountID NUMBER,
    Amount NUMBER) RETURN BOOLEAN AS
    CurrentBalance NUMBER;
BEGIN
    -- Fetch current balance for the account
    SELECT Balance INTO CurrentBalance FROM Accounts WHERE AccountID = AccountID;

    -- Check if current balance is sufficient
    IF CurrentBalance >= Amount THEN
        RETURN TRUE; -- Sufficient balance
    ELSE
        RETURN FALSE; -- Insufficient balance
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE; -- If account ID does not exist, return false
END HasSufficientBalance;










