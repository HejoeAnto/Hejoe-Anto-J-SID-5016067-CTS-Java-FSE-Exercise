-- Exercise 5: Triggers

Scenario 1: UpdateCustomerLastModified

CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    :NEW.LastModified := SYSDATE; -- Update LastModified to current date
END UpdateCustomerLastModified;


-- Scenario 2: LogTransaction

CREATE TABLE AuditLog (
    AuditID NUMBER PRIMARY KEY,
    TransactionID NUMBER,
    AuditDate DATE,
    Action VARCHAR2(50));

CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
DECLARE
    NewAuditID NUMBER;
BEGIN
    -- Generate a new AuditID (this can be done differently based on your ID generation strategy)
    SELECT AuditLog_SEQ.NEXTVAL INTO NewAuditID FROM dual; -- Assuming you have a sequence named AuditLog_SEQ

    -- Insert a record into the AuditLog
    INSERT INTO AuditLog (AuditID, TransactionID, AuditDate, Action)
    VALUES (NewAuditID, :NEW.TransactionID, SYSDATE, 'Inserted');
END LogTransaction;




-- Scenario 3: CheckTransactionRules

CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    CurrentBalance NUMBER;
BEGIN
    -- Check for withdrawal rules
    IF :NEW.TransactionType = 'Withdrawal' THEN
        SELECT Balance INTO CurrentBalance FROM Accounts WHERE AccountID = :NEW.AccountID;
        IF CurrentBalance < :NEW.Amount THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance for withdrawal in account ID ' || :NEW.AccountID);
        END IF;
    END IF;

    -- Check for deposit rules
    IF :NEW.TransactionType = 'Deposit' THEN
        IF :NEW.Amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive.');
        END IF;
    END IF;
END CheckTransactionRules;


