-- Exercise 7: Packages

-- Scenario 1: CustomerManagement Package

CREATE OR REPLACE PACKAGE CustomerManagement AS
    PROCEDURE AddNewCustomer(
        CustomerID NUMBER,
        Name VARCHAR2,
        DOB DATE,
        Balance NUMBER );

    PROCEDURE UpdateCustomerDetails(
        CustomerID NUMBER,
        Name VARCHAR2,
        DOB DATE,
        Balance NUMBER );

    FUNCTION GetCustomerBalance(CustomerID NUMBER) RETURN NUMBER;
END CustomerManagement;



CREATE OR REPLACE PACKAGE BODY CustomerManagement AS

    PROCEDURE AddNewCustomer(
        CustomerID NUMBER,
        Name VARCHAR2,
        DOB DATE,
        Balance NUMBER ) IS
    BEGIN
        INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
        VALUES (CustomerID, Name, DOB, Balance, SYSDATE);
        DBMS_OUTPUT.PUT_LINE('New customer added: ' || Name);
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.PUT_LINE('Error: Customer ID ' || CustomerID || ' already exists.');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error adding new customer: ' || SQLERRM);
    END AddNewCustomer;

    PROCEDURE UpdateCustomerDetails(
        CustomerID NUMBER,
        Name VARCHAR2,
        DOB DATE,
        Balance NUMBER ) IS
    BEGIN
        UPDATE Customers
        SET Name = Name, DOB = DOB, Balance = Balance, LastModified = SYSDATE
        WHERE CustomerID = CustomerID;
        DBMS_OUTPUT.PUT_LINE('Customer details updated for ID: ' || CustomerID);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Error: Customer ID ' || CustomerID || ' not found.');
    END UpdateCustomerDetails;

    FUNCTION GetCustomerBalance(CustomerID NUMBER) RETURN NUMBER IS
        Balance NUMBER;
    BEGIN
        SELECT Balance INTO Balance FROM Customers WHERE CustomerID = CustomerID;
        RETURN Balance;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN -1; -- Indicates customer not found
    END GetCustomerBalance;

END CustomerManagement;





-- Scenario 2: EmployeeManagement Package

CREATE OR REPLACE PACKAGE EmployeeManagement AS
    PROCEDURE HireNewEmployee(
        EmployeeID NUMBER,
        Name VARCHAR2,
        Position VARCHAR2,
        Salary NUMBER,
        Department VARCHAR2 );

    PROCEDURE UpdateEmployeeDetails(
        EmployeeID NUMBER,
        Name VARCHAR2,
        Position VARCHAR2,
        Salary NUMBER,
        Department VARCHAR2);

    FUNCTION CalculateAnnualSalary(EmployeeID NUMBER) RETURN NUMBER;
END EmployeeManagement;


CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS

    PROCEDURE HireNewEmployee(
        EmployeeID NUMBER,
        Name VARCHAR2,
        Position VARCHAR2,
        Salary NUMBER,
        Department VARCHAR2 ) IS
    BEGIN
        INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
        VALUES (EmployeeID, Name, Position, Salary, Department, SYSDATE);
        DBMS_OUTPUT.PUT_LINE('New employee hired: ' || Name);
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || EmployeeID || ' already exists.');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error hiring new employee: ' || SQLERRM);
    END HireNewEmployee;

   
 PROCEDURE UpdateEmployeeDetails(
        EmployeeID NUMBER,
        Name VARCHAR2,
        Position VARCHAR2,
        Salary NUMBER,
        Department VARCHAR2 ) IS
    BEGIN
        UPDATE Employees
        SET Name = Name, Position = Position, Salary = Salary, Department = Department
        WHERE EmployeeID = EmployeeID;
        DBMS_OUTPUT.PUT_LINE('Employee details updated for ID: ' || EmployeeID);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || EmployeeID || ' not found.');
    END UpdateEmployeeDetails;

    FUNCTION CalculateAnnualSalary(EmployeeID NUMBER) RETURN NUMBER IS
        AnnualSalary NUMBER;
    BEGIN
        SELECT Salary * 12 INTO AnnualSalary FROM Employees WHERE EmployeeID = EmployeeID;
        RETURN AnnualSalary;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN -1; -- Indicates employee not found
    END CalculateAnnualSalary;

END EmployeeManagement;


-- Scenario 3: AccountOperations Package


CREATE OR REPLACE PACKAGE AccountOperations AS
    PROCEDURE OpenNewAccount(
        AccountID NUMBER,
        CustomerID NUMBER,
        AccountType VARCHAR2,
        InitialBalance NUMBER );

    PROCEDURE CloseAccount(
        AccountID NUMBER);

    FUNCTION GetTotalBalance(CustomerID NUMBER) RETURN NUMBER;
END AccountOperations;



CREATE OR REPLACE PACKAGE BODY AccountOperations AS

    PROCEDURE OpenNewAccount(
        AccountID NUMBER,
        CustomerID NUMBER,
        AccountType VARCHAR2,
        InitialBalance NUMBER ) IS
    BEGIN
                        INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance,  LastModified)
        VALUES (AccountID, CustomerID, AccountType, InitialBalance, SYSDATE);
        DBMS_OUTPUT.PUT_LINE('New account opened for Customer ID: ' || CustomerID);
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.PUT_LINE('Error: Account ID ' || AccountID || ' already exists.');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error opening new account: ' || SQLERRM);
    END OpenNewAccount;

    PROCEDURE CloseAccount(
        AccountID NUMBER ) IS
    BEGIN
        DELETE FROM Accounts WHERE AccountID = AccountID;
        DBMS_OUTPUT.PUT_LINE('Account closed: ' || AccountID);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Error: Account ID ' || AccountID || ' not found.');
    END CloseAccount;

    FUNCTION GetTotalBalance(CustomerID NUMBER) RETURN NUMBER IS
        TotalBalance NUMBER;
    BEGIN
        SELECT SUM(Balance) INTO TotalBalance FROM Accounts WHERE CustomerID = CustomerID;
        RETURN TotalBalance;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0; -- No accounts found for the customer
    END GetTotalBalance;

END AccountOperations;



